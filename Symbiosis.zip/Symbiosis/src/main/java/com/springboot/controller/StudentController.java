package com.springboot.controller;
import java.sql.Array;
import java.util.List;

import javax.swing.text.View;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.springboot.model.Student;
import com.springboot.service.StudentService;


@Controller
public class StudentController {

    @Autowired
    private StudentService studentService;

    // display list of employees
    

 @GetMapping("/") public String viewHomePage(Model model) {
 model.addAttribute("listStudent", studentService.getAllStudent()); return
	 "Index";
 }
 
    
    @GetMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable(value="pageNo")int pageNo,Model model) 
    {
    long pageSize = 5;

    Page<Student> page = studentService.findPaginated(pageNo, pageSize);
    List<Student> listStudent = page.getContent();

    model.addAttribute("currentPage",pageNo);
    model.addAttribute("totalPages", page.getTotalPages());
    model.addAttribute("totalItems", page.getTotalElements());
    model.addAttribute("listStudent",listStudent);
    return "ViewList";

    }
	
	/*
	 * @GetMapping("/") public String ViewDetails(Model model) { return
	 * findPaginated(1, model); }
	 */
	
	 @GetMapping("/Viewlist") public String viewList(Model model) {
	 model.addAttribute("viewlist", studentService.getAllStudent()); return
	 "ViewList";
	
}
    
    @GetMapping("/showNewStudentForm")
    public String showNewStudentForm(Model model) {
        // create model attribute to bind form data
        Student Student = new Student();
        model.addAttribute("student", Student);
        return "new_Student";
    }

    @PostMapping("/saveStudent")
    public String saveStudent(@ModelAttribute("student") Student student) {
        // save employee to database
        studentService.saveStudent(student);
        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {

        // get employee from the service
        Student student = studentService.getStudentById(id);

        // set employee as a model attribute to pre-populate the form
        model.addAttribute("student", student);
        return "update_student";
    }

    @GetMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable(value = "id") long id) {

        // call delete employee method 
        this.studentService.deleteStudentById(id);
        return "redirect:/";
    }
}
