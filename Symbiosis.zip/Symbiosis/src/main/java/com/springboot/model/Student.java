package com.springboot.model;
import java.sql.Date;
import java.util.Optional;

import jakarta.persistence.*;
@Entity
@Table(name = "Student_Data")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "first_name")
    private String firstName;
@Column(name="middlename")
private String middlename;
    @Column(name = "last_name")
    private String lastName;
    @Column(name="gender")
    private String gender;
    @Column(name="date")
    private String date; 
    @Column(name = "email")
    private String email;
    
    @Column(name = "mobile")
    private long mobile;
    @Column(name = "aadhar")
    private long aadhar;
    @Column(name = "Address")
    private String address;
        @Column(name = "Qualification")
    private String qualification;
   
    @Column(name = "Percentage")
    private int percentage;
    @Column(name = "College")
    private String college;
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getMiddlename() {
        return middlename;
    }
    public void setMiddlename(String middlename) {
        this.middlename = middlename;
        }  
    
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
        }  
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
        }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
                }      
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public long getMobile() {
        return mobile;
    }
    public void setMobile(long mobile) {
        this.mobile = mobile;
    }
    public long getAadhar() {
        return aadhar;
    }
    public void setAadhar(long aadhar) {
        this.aadhar = aadhar;
    }

     public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;

	
	}
    
    public String getQualification() {
        return qualification;
    }
    public void setQualification(String qualification) {
        this.qualification = qualification;
}   
    public int getPercentage() {
        return percentage;
    }
    public void setPercentage(int percentage) {
        this.percentage = percentage;
}

    public String getCollege() {
        return college;
    }
    public void setCollege(String college) {
        this.college = college;
}}
