package com.springboot.service;
import java.util.List;

import org.springframework.data.domain.Page;

import com.springboot.model.Student;

public interface StudentService {
    List < Student > getAllStudent();
    void saveStudent(Student student);
    Student getStudentById(long id);
    void deleteStudentById(long id);
	Page<Student> findPaginated(long pageNo, long pageSize);
	Page<Student> findPaginated(int pageNo, int pageSize);
	 	
}
